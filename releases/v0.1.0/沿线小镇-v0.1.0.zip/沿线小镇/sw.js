const CACHE = 'alongline-mvox3e47';
const FILES = ["./","./index.html","./favicon.svg","./assets/index-BK6N3kEz.css","./assets/index-Cye_P2SH.js","./assets/three-D9QqeBGj.js"];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('alongline-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || (event.request.mode === 'navigate' ? caches.match('./index.html').then(page => page || fetch(event.request)) : fetch(event.request))));
});
