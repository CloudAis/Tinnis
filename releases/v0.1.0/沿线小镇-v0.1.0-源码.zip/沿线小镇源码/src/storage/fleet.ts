import { stationDistance,legDuration } from '../simulation/route-distance';
import { resourcesFor } from '../simulation/dispatch';
import { STATIONS } from '../world/map';
import { CONFIG } from '../config';
import { allTrains, newFleet, type FleetState, type VehicleReceipt, STATUS_NAMES } from '../world/fleet';
import type { WorldState, LedgerEntry } from '../world/state';
import { routeSnapshot, travelFraction } from '../simulation/train';
const record=(v:unknown):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const int=(v:unknown):v is number=>Number.isSafeInteger(v)&&(v as number)>=0;
const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
function bad():never {throw new Error('车辆存档、位置或购售凭据不一致，当前世界未更改。');}
export function copyVehicleReceipt(raw:unknown):VehicleReceipt|undefined {
  if(raw===undefined)return;
  if(!record(raw))return bad();
  if(raw.kind==='buy')return {kind:'buy',vehicleId:raw.vehicleId,type:raw.type,paid:raw.paid};
  if(raw.kind==='sell')return {kind:'sell',vehicleId:raw.vehicleId,purchaseId:raw.purchaseId};
  return bad();
}
export function validateFleet(raw:any,w:WorldState,ledger:LedgerEntry[]):FleetState {
  if(!record(raw)||!int(raw.revision)||!int(raw.nextSerial)||typeof raw.follow!=='boolean')return bad();
  let serial=1,mutations=0;const active=new Map<string,{id:string;type:'light'|'large';paid:number;purchaseId:string}>();
  for(const e of ledger){
    const r=e.vehicle;
    if(!r){if(e.id.startsWith('fleet:'))return bad();continue;}
    if(r.kind==='buy'){
      const id=`train-${String(serial).padStart(4,'0')}`;
      if(active.size>=2||r.vehicleId!==id||e.id!==`fleet:buy:${serial}`||!['light','large'].includes(r.type)||!int(r.paid)||!r.paid||e.amount!==-r.paid)return bad();
      active.set(id,{id,type:r.type,paid:r.paid,purchaseId:e.id});serial++;
    }else{
      const bought=active.get(r.vehicleId);if(!bought||r.purchaseId!==bought.purchaseId||e.id!==`fleet:sell:${bought.id}`||e.amount!==Math.floor(bought.paid*CONFIG.vehicleRefund))return bad();
      active.delete(r.vehicleId);
    }
    mutations++;
  }
  if(raw.nextSerial!==serial||raw.revision<mutations)return bad();
  const result=newFleet();result.revision=raw.revision;result.nextSerial=serial;result.follow=raw.follow;
  if(!Array.isArray(raw.others)||raw.others.length>1)return bad();
  const input=[...(raw.vehicle?[raw.vehicle]:[]),...raw.others];if(input.length!==active.size||new Set(input.map(v=>v.id)).size!==input.length||!raw.vehicle&&(input.length||raw.follow))return bad();
  function parse(v:any){
  const bought=active.get(v?.id);if(!bought)return bad();
  if(!record(v)||v.id!==bought.id||v.type!==bought.type||v.purchaseId!==bought.purchaseId||v.paid!==bought.paid||!Object.hasOwn(STATUS_NAMES,v.status)||![1,-1].includes(v.direction)||!finite(v.distance)||v.distance<0||!finite(v.legElapsed)||v.legElapsed<0||v.legElapsed>1e6||!finite(v.dwellRemaining)||v.dwellRemaining<0||v.dwellRemaining>10.000001||typeof v.stopRequested!=='boolean'||!int(v.tripSerial)||!int(v.legsCompleted)||!int(v.arrivalSerial)||v.arrivalSerial!==v.legsCompleted)return bad();
  let route=null;
  if(v.status==='depot'){
    if(v.route!==null||v.currentStation!==null||v.pendingStops!==null||v.distance!==0||v.legElapsed!==0||v.dwellRemaining!==0||raw.follow&&raw.vehicle?.id===v.id)return bad();
  }else{
    if(!record(v.route)||!Array.isArray(v.route.stops)||v.route.stops.length<2||v.route.stops.length>3||new Set(v.route.stops).size!==v.route.stops.length)return bad();
    const candidate=routeSnapshot({...w,railway:{...w.railway,line:{...w.railway.line,stops:v.route.stops}}});
    if(!candidate||JSON.stringify(candidate)!==JSON.stringify({lineId:v.route.lineId,stops:v.route.stops,nodes:v.route.nodes,edges:v.route.edges,length:v.route.length}))return bad();
    route=candidate;
    if(v.distance>route.length+1e-6)return bad();
    if(v.status==='running'||v.status==='braking'){
      const a=v.authority;if(!record(a)||!route.stops.includes(a.from)||!route.stops.includes(a.to)||route.stops.indexOf(a.to)-route.stops.indexOf(a.from)!==v.direction)return bad();
      const duration=legDuration({...v,route} as any),from=stationDistance(route,a.from),to=stationDistance(route,a.to),expected=from+(to-from)*travelFraction(v.legElapsed,duration);
      if(v.legElapsed>duration+1e-6)return bad();
      if(v.currentStation!==null||Math.abs(expected-v.distance)>1e-6||v.tripSerial!==v.legsCompleted+1||v.dwellRemaining!==0)return bad();
      if(v.status==='running'&&v.legElapsed>=duration-10+1e-6||v.status==='braking'&&v.legElapsed<duration-10-1e-6)return bad();
    }else{
      if(!route.stops.includes(v.currentStation)||Math.abs(v.distance-stationDistance(route,v.currentStation))>1e-6||v.tripSerial!==v.legsCompleted)return bad();
    }
    if(v.pendingStops!==null){
      if(!Array.isArray(v.pendingStops)||!routeSnapshot(w,v.pendingStops))return bad();
    }
  }
  if(!finite(v.totalDistance)||v.totalDistance<0)return bad();
  if(v.waitSince!==null&&(!finite(v.waitSince)||v.waitSince>w.clock.minutes+1e-6)||typeof v.waitReason!=='string')return bad();
  const validBerth=(station:any,berth:any)=>Number.isInteger(berth)&&berth>=1&&berth<=(STATIONS.find(s=>s.id===station)?.berths??0);
  let authority=null;
  if(v.currentStation){if(!validBerth(v.currentStation,v.berth)||v.authority!==null)return bad();}
  else if(v.status==='running'||v.status==='braking'){const a=v.authority;if(!record(a)||!route||a.section!==[a.from,a.to].sort().join('')||!route.stops.includes(a.from)||!route.stops.includes(a.to)||a.from===a.to||route.stops.indexOf(a.to)-route.stops.indexOf(a.from)!==v.direction||!validBerth(a.from,a.fromBerth)||!validBerth(a.to,a.berth)||v.berth!==null)return bad();authority={section:a.section,from:a.from,to:a.to,fromBerth:a.fromBerth,berth:a.berth};}
  else if(v.berth!==null||v.authority!==null)return bad();
  return {...bought,berth:v.berth,authority,waitSince:v.waitSince,waitReason:v.waitReason,totalDistance:v.totalDistance,status:v.status,route,pendingStops:v.pendingStops===null?null:[...v.pendingStops],direction:v.direction,distance:v.distance,legElapsed:v.legElapsed,dwellRemaining:v.dwellRemaining,currentStation:v.currentStation,stopRequested:v.stopRequested,tripSerial:v.tripSerial,legsCompleted:v.legsCompleted,arrivalSerial:v.arrivalSerial};
  }
  if(raw.vehicle)result.vehicle=parse(raw.vehicle);result.others=raw.others.map(parse);
  try{result.resources=resourcesFor(allTrains(result));}catch{return bad();}
  if(JSON.stringify(result.resources)!==JSON.stringify(raw.resources))return bad();
  return result;
}
